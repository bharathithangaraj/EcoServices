-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.5.45 - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             10.1.0.5464
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for payment_v1
CREATE DATABASE IF NOT EXISTS `payment_v1` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `payment_v1`;

-- Dumping structure for table payment_v1.payment
CREATE TABLE IF NOT EXISTS `payment` (
  `payment_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_on` datetime NOT NULL,
  `modified_on` datetime NOT NULL,
  `order_id` bigint(20) DEFAULT NULL,
  `payment_type` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`payment_id`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;

-- Dumping data for table payment_v1.payment: 20 rows
DELETE FROM `payment`;
/*!40000 ALTER TABLE `payment` DISABLE KEYS */;
INSERT INTO `payment` (`payment_id`, `created_on`, `modified_on`, `order_id`, `payment_type`, `status`, `user_id`) VALUES
	(28, '2019-06-11 18:05:08', '2019-06-11 18:05:08', 139, 'CARD', 1, 1),
	(31, '2019-06-12 18:20:15', '2019-06-12 18:20:15', 142, 'CARD', 1, 1),
	(30, '2019-06-12 18:20:15', '2019-06-12 18:20:15', 141, 'CARD', 1, 1),
	(29, '2019-06-11 23:42:16', '2019-06-11 23:42:16', 140, 'CARD', 1, 1),
	(27, '2019-06-11 18:05:08', '2019-06-11 18:05:08', 138, 'CARD', 1, 1),
	(26, '2019-06-11 18:05:08', '2019-06-11 18:05:08', 137, 'CARD', 1, 1),
	(25, '2019-06-11 18:05:08', '2019-06-11 18:05:08', 136, 'CARD', 1, 1),
	(24, '2019-06-11 18:05:08', '2019-06-11 18:05:08', 135, 'CARD', 1, 1),
	(23, '2019-06-11 18:05:08', '2019-06-11 18:05:08', 134, 'CARD', 1, 1),
	(22, '2019-06-11 18:05:08', '2019-06-11 18:05:08', 133, 'CARD', 1, 1),
	(32, '2019-06-12 18:20:15', '2019-06-12 18:20:15', 143, 'CARD', 1, 1),
	(33, '2019-06-12 18:20:15', '2019-06-12 18:20:15', 144, 'CARD', 1, 1),
	(34, '2019-06-12 18:20:15', '2019-06-12 18:20:15', 145, 'CARD', 1, 1),
	(35, '2019-06-12 18:20:15', '2019-06-12 18:20:15', 146, 'CARD', 1, 1),
	(36, '2019-06-12 18:20:15', '2019-06-12 18:20:15', 147, 'CARD', 1, 1),
	(37, '2019-06-12 18:20:15', '2019-06-12 18:20:15', 148, 'CARD', 1, 1),
	(38, '2019-06-12 18:20:15', '2019-06-12 18:20:15', 149, 'CARD', 1, 1),
	(39, '2019-06-12 18:20:15', '2019-06-12 18:20:15', 150, 'CARD', 1, 1),
	(40, '2019-06-12 18:20:15', '2019-06-12 18:20:15', 151, 'CARD', 1, 1),
	(41, '2019-06-12 18:20:15', '2019-06-12 18:20:15', 152, 'CARD', 1, 1);
/*!40000 ALTER TABLE `payment` ENABLE KEYS */;

-- Dumping structure for table payment_v1.payment_details
CREATE TABLE IF NOT EXISTS `payment_details` (
  `payment_detail_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `card_holder_name` varchar(255) DEFAULT NULL,
  `card_no` varchar(255) DEFAULT NULL,
  `created_on` datetime NOT NULL,
  `cvv` int(11) NOT NULL,
  `exp_date` varchar(255) DEFAULT NULL,
  `modified_on` datetime NOT NULL,
  `payment_id` bigint(20) DEFAULT NULL,
  `price` double NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`payment_detail_id`)
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=latin1;

-- Dumping data for table payment_v1.payment_details: 20 rows
DELETE FROM `payment_details`;
/*!40000 ALTER TABLE `payment_details` DISABLE KEYS */;
INSERT INTO `payment_details` (`payment_detail_id`, `card_holder_name`, `card_no`, `created_on`, `cvv`, `exp_date`, `modified_on`, `payment_id`, `price`, `status`) VALUES
	(35, '', '', '2019-06-12 18:20:15', 0, NULL, '2019-06-12 18:20:15', 34, 0, 1),
	(34, '', '', '2019-06-12 18:20:15', 0, NULL, '2019-06-12 18:20:15', 33, 0, 1),
	(33, '', '', '2019-06-12 18:20:15', 0, NULL, '2019-06-12 18:20:15', 32, 0, 1),
	(32, '', '', '2019-06-12 18:20:15', 0, NULL, '2019-06-12 18:20:15', 31, 0, 1),
	(31, 'bharathi', '123812938190312', '2019-06-12 18:20:15', 123, NULL, '2019-06-12 18:20:15', 30, 0, 1),
	(30, 'Bharathi `', '123123123123123', '2019-06-11 23:42:16', 124, NULL, '2019-06-11 23:42:16', 29, 0, 1),
	(29, 'Bharathi', '12345678000034223', '2019-06-11 18:05:08', 124, NULL, '2019-06-11 18:05:08', 28, 0, 1),
	(28, 'Bharathi', '12345678000034223', '2019-06-11 18:05:08', 124, NULL, '2019-06-11 18:05:08', 27, 0, 1),
	(27, 'Bharathi', '12345678000034223', '2019-06-11 18:05:08', 124, NULL, '2019-06-11 18:05:08', 26, 0, 1),
	(26, 'Bharathi', '12345678000034223', '2019-06-11 18:05:08', 124, NULL, '2019-06-11 18:05:08', 25, 0, 1),
	(25, 'Bharathi T ', '12345678901234567', '2019-06-11 18:05:08', 124, NULL, '2019-06-11 18:05:08', 24, 0, 1),
	(24, 'Bharathi T ', '12345678901234567', '2019-06-11 18:05:08', 124, NULL, '2019-06-11 18:05:08', 23, 0, 1),
	(23, 'Bharathi T ', '12345678901234567', '2019-06-11 18:05:08', 124, NULL, '2019-06-11 18:05:08', 22, 0, 1),
	(36, 'bharathi ', '1234567890123456', '2019-06-12 18:20:15', 234, NULL, '2019-06-12 18:20:15', 35, 0, 1),
	(37, 'bharathi ', '1234567890123456', '2019-06-12 18:20:15', 234, NULL, '2019-06-12 18:20:15', 36, 0, 1),
	(38, 'bharathi ', '1234567890123456', '2019-06-12 18:20:15', 234, NULL, '2019-06-12 18:20:15', 37, 0, 1),
	(39, '', '', '2019-06-12 18:20:15', 0, NULL, '2019-06-12 18:20:15', 38, 0, 1),
	(40, '', '', '2019-06-12 18:20:15', 0, NULL, '2019-06-12 18:20:15', 39, 0, 1),
	(41, '', '', '2019-06-12 18:20:15', 0, NULL, '2019-06-12 18:20:15', 40, 0, 1),
	(42, '', '', '2019-06-12 18:20:15', 0, NULL, '2019-06-12 18:20:15', 41, 0, 1);
/*!40000 ALTER TABLE `payment_details` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
